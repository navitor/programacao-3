
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import BD.BD_Cliente;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import model.Cliente;

/**
 *
 * @author alunos
 */
public class ControlCaixa {
    JTextField jTStatus1;
    JTextField jTNome1;
    JTextField jTValorMesa1;
    JList<String> jLConsumo1;

    JTextField jTStatus2;
    JTextField jTNome2;
    JTextField jTValorMesa2;
    JList<String> jLConsumo2;

    JTextField jTStatus3;
    JTextField jTNome3;
    JTextField jTValorMesa3;
    JList<String> jLConsumo3;

    JTextField jTStatus4;
    JTextField jTNome4;
    JTextField jTValorMesa4;
    JList<String> jLConsumo4;

    public ControlCaixa(JTextField jTStatus1, JTextField jTNome1, JTextField jTValorMesa1, JList<String> jLConsumo1, JTextField jTStatus2, JTextField jTNome2, JTextField jTValorMesa2, JList<String> jLConsumo2, JTextField jTStatus3, JTextField jTNome3, JTextField jTValorMesa3, JList<String> jLConsumo3, JTextField jTStatus4, JTextField jTNome4, JTextField jTValorMesa4, JList<String> jLConsumo4) {
        this.jTStatus1 = jTStatus1;
        this.jTStatus2 = jTStatus2;
        this.jTStatus3 = jTStatus3;
        this.jTStatus4 = jTStatus4;
        this.jTNome1 = jTNome1;
        this.jTNome2 = jTNome2;
        this.jTNome3 = jTNome3;
        this.jTNome4 = jTNome4;
        this.jTValorMesa1 = jTValorMesa1;
        this.jTValorMesa2 = jTValorMesa2;
        this.jTValorMesa3 = jTValorMesa3;
        this.jTValorMesa4 = jTValorMesa4;
        this.jLConsumo1 = jLConsumo1;
        this.jLConsumo2 = jLConsumo2;
        this.jLConsumo3 = jLConsumo3;
        this.jLConsumo4 = jLConsumo4;
        
    }
    
    
    ArrayList<Cliente> BDClientes = new ArrayList<>();
    
    BD_Cliente bD_Cliente = new BD_Cliente();
 
    public void atualizando(){
        BDClientes = bD_Cliente.carregarBanco();
        for (Cliente cli : BDClientes) {
            if (cli.getStatus() == 0){
                if(cli.getMesa()==1){
                    jTNome1.setText(cli.getNome());
                    jTStatus1.setText("Aguardando Pedido!");
                }
                if(cli.getMesa()==2){
                    jTNome2.setText(cli.getNome());
                    jTStatus2.setText("Aguardando Pedido!");
                }
                if(cli.getMesa()==3){
                    jTNome3.setText(cli.getNome());
                    jTStatus3.setText("Aguardando Pedido!");
                }
                if(cli.getMesa()==4){
                    jTNome4.setText(cli.getNome());
                    jTStatus4.setText("Aguardando Pedido!");
                }
            }
        }
        
    }
    
}
