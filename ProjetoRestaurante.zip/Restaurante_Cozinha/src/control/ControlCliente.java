
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import javax.swing.JComboBox;
import javax.swing.JTextField;

/**
 *
 * @author alunos
 */
public class ControlCliente {
    JTextField jTNome;
    JComboBox<String> jCMesa;
    JTextField jTP1P;
    
    
}
